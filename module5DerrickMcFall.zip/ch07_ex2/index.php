<?php 
    //set default value of variables for initial page load
    if (!isset($investment)) { $investment = '10000'; } 
    if (!isset($interest_rate)) { $interest_rate = '5'; } 
    if (!isset($years)) { $years = '5'; } 
?>
<!DOCTYPE html>
<html>

<head>
    <title>Future Value Calculator</title>
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>

<body>
    <main>
        <h1>Future Value Calculator</h1>
        <?php if (!empty($error_message)) { ?>
        <p class="error"><?php echo $error_message; ?></p>
        <?php } // end if ?>
        <form action="display_results.php" method="post">

            <div id="data">
                <label>Investment Amount:</label>
                <select name="investment">
                    <option>
                        <?php echo 10000; ?>
                    </option>
                    <option>
                        <?php echo 15000; ?>
                    </option>
                    <option>
                        <?php echo 20000; ?>
                    </option>
                    <option>
                        <?php echo 25000; ?>
                    </option>
                    <option>
                        <?php echo 30000; ?>
                    </option>
                    <option>
                        <?php echo 35000; ?>
                    </option>
                    <option>
                        <?php echo 40000; ?>
                    </option>
                    <option>
                        <?php echo 45000; ?>
                    </option>
                    <option>
                        <?php echo 50000; ?>
                    </option>



                    <!-- <?php for($v=10000; $v <= 50000; $v +=5000):?>
                    <option value="<?php echo $v; ?>">
                        <?php echo $v; ?>
                    </option>
                    <?php endfor ?> -->
                </select>
                <br>

                <label>Yearly Interest Rate:</label>
                <select name='interest_rate'>
                <option>
                <?php echo 4; ?>
                </option>
                <option>
                <?php echo 4.5; ?>
                </option>
                <option>
                <?php echo 5; ?>
                </option>
                <option>
                <?php echo 5.5; ?>
                </option>
                <option>
                <?php echo 6; ?>
                </option>
                <option>
                <?php echo 6.5; ?>
                </option>
                <option>
                <?php echo 7; ?>
                </option>
                <option>
                <?php echo 7.5; ?>
                </option>
                <option>
                <?php echo 8; ?>
                </option>
                <option>
                <?php echo 8.5; ?>
                </option>
                <option>
                <?php echo 9; ?>
                </option>
                <option>
                <?php echo 9.5; ?>
                </option>
                <option>
                <?php echo 10; ?>
                </option>
                <option>
                <?php echo 10.5; ?>
                </option>
                <option>
                <?php echo 11; ?>
                </option>
                <option>
                <?php echo 11.5; ?>
                </option>
                <option>
                <?php echo 12; ?>
                </option>
                    <!-- <?php for ($v = 4; $v <= 12; $v += .5): ?>
                    <option value="<?php echo $v; ?>">
                        <?php echo $v; ?>
                    </option>
                    <?php endfor ?> -->
                </select>


                <br>

                <label>Number of Years:</label>
                <input type="text" name="years" value="<?php echo $years; ?>" /><br>
            </div>

            <div id="buttons">
                <label>&nbsp;</label>
                <input type="submit" value="Calculate" /><br>
            </div>

        </form>
    </main>
</body>

</html>